<?php
require 'email.class.php';
require 'LiqPay.php';
$params = require 'params.php';
//data - function result base64_encode( $json_string )
//signature - function result base64_encode( sha1( $private_key . $data . $private_key ) )
if (isset($_GET['data'])) {
    $data = json_decode($_GET['data']);
}
$email = new Email();
echo "<pre>";

if ($data->paymentMethod == 'onlinePayment') {
    $amount = 0.01;
    $publicKey = $params['liqpay']['publicKey'];
    $privateKey = $params['liqpay']['privateKey'];
    $lp = new LiqPay($publicKey, $privateKey);
    $url = $lp->cnb_form(array(
        'version'        => '3',
        'amount'         => $amount,
        'currency'       => 'UAH',
        'description'    => 'description text',
        'server_url'    => 'burger.loc/scripts/success.php?data=server',
        'result_url'    => 'burger.loc/scripts/success.php?data=result',
    ));

    header("Location: {$url}");
}
//var_dump($email->sendEmail($data));




$publicKey = 'i36978302591';
$privateKey = 'TiosRWRSKKpwr86vMEDDa4Bsqnca9EVnFvYn4qhu';
$lp = new LiqPay($publicKey, $privateKey);
$url = $lp->cnb_form(array(
    'version'        => '3',
    'amount'         => $amount,
    'currency'       => 'UAH',
    'description'    => 'description text',
    'order_id'       => 'order_id_1',
    'sandbox'        => 1,
));
//print $url;
?>

