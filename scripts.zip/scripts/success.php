<?php
print 'success';
require 'email.class.php';

$email  = new Email();
var_dump($email->sendEmail(implode($_POST)));