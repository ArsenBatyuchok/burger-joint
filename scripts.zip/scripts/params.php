<?php
return [
    'liqpay' => [
        'publicKey' => 'i36978302591',
        'privateKey' => 'TiosRWRSKKpwr86vMEDDa4Bsqnca9EVnFvYn4qhu',
    ],
    'database' => [
        'username' => 'root',
        'password' => 'root',
        'host' => 'localhost',
        'dbname' => 'burger',
        'port' => '3306'
    ]

];