<?php
require 'classes/database.class.php';

$db = new Database();
var_dump($db->setAsPaid(1));

