<?php

class Sms
{

    public function __construct()
    {
        $params = require 'params.php';

    }

    public function sendSms()
    {
    }

}
