<?php
return [
    'main' => [
        'host' => 'burger.loc/',
    ],
    'liqpay' => [
        'publicKey' => 'i34110847150',
        'privateKey' => 'WikAcj8WW0pOSeMOHSF8NjLxxIUm1zAbXg44toSP',
    ],
    'database' => [
        'username' => 'root',
        'password' => 'root',
        'host' => 'localhost',
        'dbname' => 'burger',
        'port' => '3306',
    ],
    'mailGun' => [
        'domain' => 'sandbox826ba91f3f2e476dbd8feefea0b862c6.mailgun.org',
        'apiKey' => 'key-1eae68b8cb8b09e02812654165771ea5',
        'email' => 'alexandr.vasiliev@iqria.com',
    ],
    'SmsUkraine' => [
        'login' => '380673702022',
        'password' => '123456',
    ],

];